This zip archive contains data files from Cricsheet in JSON format. This
archive contains 17 T20 Blaze matches.


The JSON data files contained in this zip file are version 1.0.0, and 1.1.0
files. You can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/blz_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2019-03-29 - club - BLZ - female - wi_201706 - Trinidad and Tobago vs Windward Islands
2019-03-29 - club - BLZ - female - wi_201707 - Barbados vs Jamaica
2019-04-02 - club - BLZ - female - wi_201713 - Guyana vs Windward Islands
2019-04-03 - club - BLZ - female - wi_201716 - Guyana vs Barbados
2022-06-07 - club - BLZ - female - wi_211824 - Leeward Islands vs Windward Islands
2022-06-07 - club - BLZ - female - wi_211825 - Barbados vs Guyana
2022-06-07 - club - BLZ - female - wi_211826 - Jamaica vs Trinidad and Tobago
2022-06-09 - club - BLZ - female - wi_211828 - Leeward Islands vs Barbados
2022-06-09 - club - BLZ - female - wi_211829 - Jamaica vs Windward Islands
2022-06-11 - club - BLZ - female - wi_211830 - Barbados vs Windward Islands
2022-06-11 - club - BLZ - female - wi_211831 - Jamaica vs Guyana
2022-06-11 - club - BLZ - female - wi_211832 - Leeward Islands vs Trinidad and Tobago
2022-06-13 - club - BLZ - female - wi_211833 - Jamaica vs Barbados
2022-06-13 - club - BLZ - female - wi_211834 - Windward Islands vs Trinidad and Tobago
2022-06-13 - club - BLZ - female - wi_211835 - Leeward Islands vs Guyana
2022-06-14 - club - BLZ - female - wi_211836 - Jamaica vs Leeward Islands
2022-06-14 - club - BLZ - female - wi_211838 - Windward Islands vs Guyana
