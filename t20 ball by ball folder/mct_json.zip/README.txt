This zip archive contains data files from Cricsheet in JSON format. This
archive contains 72 Major Clubs T20 Tournament matches.


The JSON data files contained in this zip file are version 1.0.0, and 1.1.0
files. You can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/mct_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2025-06-15 - club - MCT - male - 1485338 - Panadura Sports Club vs Colombo Cricket Club
2025-06-13 - club - MCT - male - 1485337 - Moors Sports Club vs Colombo Cricket Club
2025-06-13 - club - MCT - male - 1485336 - Panadura Sports Club vs Nondescripts Cricket Club
2025-06-12 - club - MCT - male - 1485335 - Panadura Sports Club vs Colts Cricket Club
2025-06-12 - club - MCT - male - 1485334 - Moors Sports Club vs Bloomfield Cricket and Athletic Club
2025-06-11 - club - MCT - male - 1485333 - Colombo Cricket Club vs Burgher Recreation Club
2025-06-11 - club - MCT - male - 1485332 - Tamil Union Cricket and Athletic Club vs Nondescripts Cricket Club
2025-06-08 - club - MCT - male - 1485331 - Colts Cricket Club vs Police Sports Club
2025-06-08 - club - MCT - male - 1485330 - Badureliya Sports Club vs Moors Sports Club
2025-06-08 - club - MCT - male - 1485329 - Chilaw Marians Cricket Club vs Burgher Recreation Club
2025-06-08 - club - MCT - male - 1485328 - Bloomfield Cricket and Athletic Club vs Tamil Union Cricket and Athletic Club
2025-06-08 - club - MCT - male - 1485327 - Nondescripts Cricket Club vs Ace Capital Cricket Club
2025-06-08 - club - MCT - male - 1485326 - Panadura Sports Club vs Colombo Cricket Club
2025-06-06 - club - MCT - male - 1485325 - Nondescripts Cricket Club vs Panadura Sports Club
2025-06-06 - club - MCT - male - 1485324 - Nugegoda Sports Welfare Club vs Colts Cricket Club
2025-06-06 - club - MCT - male - 1485323 - Colombo Cricket Club vs Kurunegala Youth Cricket Club
2025-06-06 - club - MCT - male - 1485322 - Tamil Union Cricket and Athletic Club vs Chilaw Marians Cricket Club
2025-06-06 - club - MCT - male - 1485321 - Badureliya Sports Club vs Ace Capital Cricket Club
2025-06-06 - club - MCT - male - 1485320 - Police Sports Club vs Bloomfield Cricket and Athletic Club
2025-06-05 - club - MCT - male - 1485319 - Chilaw Marians Cricket Club vs Police Sports Club
2025-06-05 - club - MCT - male - 1485318 - Moors Sports Club vs Nondescripts Cricket Club
2025-06-05 - club - MCT - male - 1485317 - Tamil Union Cricket and Athletic Club vs Nugegoda Sports Welfare Club
2025-06-05 - club - MCT - male - 1485316 - Panadura Sports Club vs Badureliya Sports Club
2025-06-05 - club - MCT - male - 1485315 - Bloomfield Cricket and Athletic Club vs Burgher Recreation Club
2025-06-05 - club - MCT - male - 1485314 - Kurunegala Youth Cricket Club vs Ace Capital Cricket Club
2025-05-28 - club - MCT - male - 1485309 - Nugegoda Sports Welfare Club vs Chilaw Marians Cricket Club
2025-05-26 - club - MCT - male - 1485307 - Tamil Union Cricket and Athletic Club vs Police Sports Club
2025-05-26 - club - MCT - male - 1485306 - Ace Capital Cricket Club vs Panadura Sports Club
2025-05-25 - club - MCT - male - 1485301 - Kurunegala Youth Cricket Club vs Panadura Sports Club
2025-05-25 - club - MCT - male - 1485300 - Chilaw Marians Cricket Club vs Bloomfield Cricket and Athletic Club
2025-05-25 - club - MCT - male - 1485299 - Badureliya Sports Club vs Nondescripts Cricket Club
2025-05-25 - club - MCT - male - 1485298 - Nugegoda Sports Welfare Club vs Police Sports Club
2025-05-25 - club - MCT - male - 1485297 - Burgher Recreation Club vs Colts Cricket Club
2025-05-25 - club - MCT - male - 1485296 - Moors Sports Club vs Colombo Cricket Club
2025-05-16 - club - MCT - male - 1485295 - Tamil Union Cricket and Athletic Club vs Colts Cricket Club
2025-05-16 - club - MCT - male - 1485294 - Kurunegala Youth Cricket Club vs Nondescripts Cricket Club
2025-05-16 - club - MCT - male - 1485293 - Panadura Sports Club vs Moors Sports Club
2025-05-16 - club - MCT - male - 1485292 - Ace Capital Cricket Club vs Colombo Cricket Club
2025-05-16 - club - MCT - male - 1485291 - Nugegoda Sports Welfare Club vs Bloomfield Cricket and Athletic Club
2025-05-16 - club - MCT - male - 1485290 - Burgher Recreation Club vs Police Sports Club
2024-06-28 - club - MCT - male - 1432991 - Bloomfield Cricket and Athletic Club vs Nondescripts Cricket Club
2024-06-26 - club - MCT - male - 1432990 - Moors Sports Club vs Bloomfield Cricket and Athletic Club
2024-06-26 - club - MCT - male - 1432989 - Burgher Recreation Club vs Nondescripts Cricket Club
2024-06-24 - club - MCT - male - 1432988 - Burgher Recreation Club vs Tamil Union Cricket and Athletic Club
2024-06-24 - club - MCT - male - 1432987 - Ace Capital Cricket Club vs Moors Sports Club
2024-06-24 - club - MCT - male - 1432985 - Colts Cricket Club vs Nondescripts Cricket Club
2024-05-18 - club - MCT - male - 1432980 - Kurunegala Youth Cricket Club vs Bloomfield Cricket and Athletic Club
2024-05-18 - club - MCT - male - 1432979 - Panadura Sports Club vs Colts Cricket Club
2024-05-18 - club - MCT - male - 1432977 - Police Sports Club vs Nondescripts Cricket Club
2024-05-17 - club - MCT - male - 1432976 - Ace Capital Cricket Club vs Tamil Union Cricket and Athletic Club
2024-05-17 - club - MCT - male - 1432975 - Burgher Recreation Club vs Moors Sports Club
2024-05-17 - club - MCT - male - 1432974 - Sinhalese Sports Club vs Negombo Cricket Club
2024-05-17 - club - MCT - male - 1432973 - Badureliya Sports Club vs Chilaw Marians Cricket Club
2024-05-16 - club - MCT - male - 1432972 - Kurunegala Youth Cricket Club vs Colts Cricket Club
2024-05-16 - club - MCT - male - 1432971 - Kandy Customs Cricket Club vs Panadura Sports Club
2024-05-16 - club - MCT - male - 1432970 - Nugegoda Sports Welfare Club vs Police Sports Club
2024-05-16 - club - MCT - male - 1432969 - Nondescripts Cricket Club vs Ragama Cricket Club
2024-05-15 - club - MCT - male - 1432968 - Ace Capital Cricket Club vs Sinhalese Sports Club
2024-05-15 - club - MCT - male - 1432967 - Tamil Union Cricket and Athletic Club vs Negombo Cricket Club
2024-05-15 - club - MCT - male - 1432966 - Chilaw Marians Cricket Club vs Moors Sports Club
2024-05-15 - club - MCT - male - 1432965 - Badureliya Sports Club vs Burgher Recreation Club
2024-05-14 - club - MCT - male - 1432964 - Panadura Sports Club vs Bloomfield Cricket and Athletic Club
2024-05-14 - club - MCT - male - 1432963 - Colombo Cricket Club vs Police Sports Club
2024-05-14 - club - MCT - male - 1432962 - Kandy Customs Cricket Club vs Colts Cricket Club
2024-05-14 - club - MCT - male - 1432961 - Nugegoda Sports Welfare Club vs Nondescripts Cricket Club
2024-05-13 - club - MCT - male - 1432960 - Tamil Union Cricket and Athletic Club vs Sinhalese Sports Club
2024-05-13 - club - MCT - male - 1432959 - Negombo Cricket Club vs Ace Capital Cricket Club
2024-05-13 - club - MCT - male - 1432958 - Chilaw Marians Cricket Club vs Burgher Recreation Club
2024-05-13 - club - MCT - male - 1432957 - Badureliya Sports Club vs Moors Sports Club
2024-05-12 - club - MCT - male - 1432956 - Panadura Sports Club vs Kurunegala Youth Cricket Club
2024-05-12 - club - MCT - male - 1432955 - Kandy Customs Cricket Club vs Bloomfield Cricket and Athletic Club
2024-05-12 - club - MCT - male - 1432953 - Colombo Cricket Club vs Nugegoda Sports Welfare Club
